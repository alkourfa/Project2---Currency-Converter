public class myLink {
    
    private String link;
	
	public myLink(String link){
		this.link = link;
	}
	
	public String getLink(){
		return link;
	}
    
}
